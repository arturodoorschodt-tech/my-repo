import { Gift } from 'lucide-react';

const gifts = [
  {
    brand: 'IUNIK',
    offer: 'FREE BETA GLUCAN SERUM OR CREAM',
    condition: 'on IUNIK orders over €20',
    bg: 'from-amber-50 to-yellow-100',
    accent: '#D97706',
    image: 'https://images.unsplash.com/photo-1648712789205-4a05ebb8d026?w=500&q=80',
  },
  {
    brand: 'ANUA',
    offer: 'FREE RICE 70 GLOW MILKY TONER (40 ml)',
    condition: 'on all Anua orders over €35',
    bg: 'from-green-50 to-emerald-100',
    accent: '#059669',
    image: 'https://images.unsplash.com/photo-1648712789552-a039336cecf9?w=500&q=80',
  },
];

export function FreeGiftsSection() {
  return (
    <section className="py-10 bg-secondary/50">
      <div className="max-w-7xl mx-auto px-4">
        <h2
          className="text-2xl font-bold mb-6 text-center"
          style={{ fontFamily: 'DM Serif Display, serif' }}
        >
          Free Gifts
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {gifts.map((gift) => (
            <a
              key={gift.brand}
              href="#"
              className={`relative overflow-hidden rounded-2xl bg-gradient-to-r ${gift.bg} p-6 flex items-center gap-6 hover:scale-[1.01] transition-transform group`}
            >
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <Gift size={16} style={{ color: gift.accent }} />
                  <span
                    className="text-xs font-bold tracking-widest uppercase"
                    style={{ color: gift.accent }}
                  >
                    {gift.brand}
                  </span>
                </div>
                <h3 className="text-lg font-bold text-foreground mb-1 leading-snug">{gift.offer}</h3>
                <p className="text-sm text-muted-foreground">{gift.condition}</p>
              </div>
              <div className="w-24 h-24 flex-shrink-0 rounded-xl overflow-hidden shadow-md group-hover:scale-105 transition-transform">
                <img src={gift.image} alt={gift.brand} className="w-full h-full object-cover" />
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
