const categories = [
  { name: 'Cleansers', emoji: '🧼', image: 'https://images.unsplash.com/photo-1686831757685-de3cadfc2325?w=200&q=80' },
  { name: 'Exfoliators', emoji: '✨', image: 'https://images.unsplash.com/photo-1686831889593-d49e5cf9300d?w=200&q=80' },
  { name: 'Toners', emoji: '💧', image: 'https://images.unsplash.com/photo-1686831889344-f8cb3a384bc0?w=200&q=80' },
  { name: 'Essences', emoji: '🌸', image: 'https://images.unsplash.com/photo-1648712787765-82c244f76a1d?w=200&q=80' },
  { name: 'Serums', emoji: '🧪', image: 'https://images.unsplash.com/photo-1648712789205-4a05ebb8d026?w=200&q=80' },
  { name: 'Ampoules', emoji: '💎', image: 'https://images.unsplash.com/photo-1648712789552-a039336cecf9?w=200&q=80' },
  { name: 'Moisturizers', emoji: '🫧', image: 'https://images.unsplash.com/photo-1611861317409-7dcc62856a8a?w=200&q=80' },
  { name: 'Face Masks', emoji: '🎭', image: 'https://images.unsplash.com/photo-1648712787208-7d52a79c4273?w=200&q=80' },
  { name: 'Eye Care', emoji: '👁️', image: 'https://images.unsplash.com/photo-1686831757685-de3cadfc2325?w=200&q=80' },
  { name: 'Lip Care', emoji: '💋', image: 'https://images.unsplash.com/photo-1686831889344-f8cb3a384bc0?w=200&q=80' },
  { name: 'Sunscreens', emoji: '☀️', image: 'https://images.unsplash.com/photo-1686831889593-d49e5cf9300d?w=200&q=80' },
  { name: 'Make Up', emoji: '💄', image: 'https://images.unsplash.com/photo-1648712787765-82c244f76a1d?w=200&q=80' },
  { name: 'Body Care', emoji: '🌿', image: 'https://images.unsplash.com/photo-1648712789205-4a05ebb8d026?w=200&q=80' },
  { name: 'Hair Care', emoji: '💇', image: 'https://images.unsplash.com/photo-1648712789552-a039336cecf9?w=200&q=80' },
  { name: 'Hand Care', emoji: '🤲', image: 'https://images.unsplash.com/photo-1611861317409-7dcc62856a8a?w=200&q=80' },
  { name: 'Accessories', emoji: '🧰', image: 'https://images.unsplash.com/photo-1648712787208-7d52a79c4273?w=200&q=80' },
];

export function CategoriesSection() {
  return (
    <section className="py-10 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <h2
          className="text-2xl font-bold mb-6 text-center"
          style={{ fontFamily: 'DM Serif Display, serif' }}
        >
          Shop by Category
        </h2>
        <div className="grid grid-cols-4 sm:grid-cols-6 lg:grid-cols-8 gap-3">
          {categories.map((cat) => (
            <a
              key={cat.name}
              href="#"
              className="group flex flex-col items-center gap-2 p-2 rounded-xl hover:bg-secondary transition-colors"
            >
              <div className="w-14 h-14 rounded-full overflow-hidden bg-secondary border border-border group-hover:border-primary/30 transition-colors">
                <img
                  src={cat.image}
                  alt={cat.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
              </div>
              <span className="text-[10px] font-semibold text-center text-foreground/80 group-hover:text-primary transition-colors uppercase tracking-wide leading-tight">
                {cat.name}
              </span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
