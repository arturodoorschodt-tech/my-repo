import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const slides = [
  {
    id: 1,
    title: 'GLOW SECRET',
    subtitle: 'Discover the collection',
    bg: 'from-pink-100 to-rose-50',
    accent: 'hsl(336, 72%, 55%)',
    image: 'https://images.unsplash.com/photo-1686831757685-de3cadfc2325?w=1400&q=80',
  },
  {
    id: 2,
    title: 'AESTURA',
    subtitle: 'Barrier repair experts',
    bg: 'from-sky-50 to-blue-100',
    accent: '#3B82F6',
    image: 'https://images.unsplash.com/photo-1686831889593-d49e5cf9300d?w=1400&q=80',
  },
  {
    id: 3,
    title: 'ANUA',
    subtitle: 'Free Glow Milky Toner on orders over €35',
    bg: 'from-green-50 to-emerald-100',
    accent: '#10B981',
    image: 'https://images.unsplash.com/photo-1686831889344-f8cb3a384bc0?w=1400&q=80',
  },
  {
    id: 4,
    title: 'IUNIK',
    subtitle: '15% OFF + Free serum with every order',
    bg: 'from-amber-50 to-yellow-100',
    accent: '#F59E0B',
    image: 'https://images.unsplash.com/photo-1648712787765-82c244f76a1d?w=1400&q=80',
  },
];

export function HeroSlider() {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => setCurrent((c) => (c + 1) % slides.length), 5000);
    return () => clearInterval(timer);
  }, []);

  const prev = () => setCurrent((c) => (c - 1 + slides.length) % slides.length);
  const next = () => setCurrent((c) => (c + 1) % slides.length);

  return (
    <div className="relative overflow-hidden bg-secondary" style={{ height: '420px' }}>
      {slides.map((slide, i) => (
        <div
          key={slide.id}
          className={`absolute inset-0 transition-opacity duration-700 ${i === current ? 'opacity-100' : 'opacity-0'}`}
        >
          <div className={`absolute inset-0 bg-gradient-to-r ${slide.bg}`} />
          <img
            src={slide.image}
            alt={slide.title}
            className="absolute right-0 top-0 h-full w-1/2 object-cover opacity-40"
          />
          <div className="relative max-w-7xl mx-auto px-8 h-full flex flex-col justify-center">
            <div className="animate-slide-in max-w-md">
              <p className="text-xs font-semibold tracking-widest uppercase mb-2 text-muted-foreground">
                New Collection
              </p>
              <h1
                className="text-5xl md:text-6xl font-bold mb-3 leading-tight"
                style={{ fontFamily: 'DM Serif Display, serif', color: slide.accent }}
              >
                {slide.title}
              </h1>
              <p className="text-base text-foreground/80 mb-6">{slide.subtitle}</p>
              <a
                href="#"
                className="inline-flex items-center px-6 py-2.5 rounded-full text-sm font-semibold text-white transition-all hover:scale-105 active:scale-95"
                style={{ backgroundColor: slide.accent }}
              >
                Shop Now
              </a>
            </div>
          </div>
        </div>
      ))}

      {/* Controls */}
      <button
        onClick={prev}
        className="absolute left-4 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-white/80 hover:bg-white shadow flex items-center justify-center transition-all hover:scale-110"
        aria-label="Previous"
      >
        <ChevronLeft size={18} />
      </button>
      <button
        onClick={next}
        className="absolute right-4 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-white/80 hover:bg-white shadow flex items-center justify-center transition-all hover:scale-110"
        aria-label="Next"
      >
        <ChevronRight size={18} />
      </button>

      {/* Dots */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
        {slides.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrent(i)}
            className={`h-2 rounded-full transition-all ${
              i === current ? 'bg-primary w-5' : 'w-2 bg-white/60 hover:bg-white'
            }`}
            aria-label={`Slide ${i + 1}`}
          />
        ))}
      </div>
    </div>
  );
}
