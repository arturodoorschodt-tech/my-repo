const trendingBrands = [
  { name: 'MEDICUBE', bg: 'bg-pink-50', image: 'https://images.unsplash.com/photo-1686831757685-de3cadfc2325?w=300&q=80' },
  { name: 'CELIMAX', bg: 'bg-green-50', image: 'https://images.unsplash.com/photo-1686831889593-d49e5cf9300d?w=300&q=80' },
  { name: 'SKIN1004', bg: 'bg-sky-50', image: 'https://images.unsplash.com/photo-1648712787765-82c244f76a1d?w=300&q=80' },
  { name: 'ANUA', bg: 'bg-emerald-50', image: 'https://images.unsplash.com/photo-1648712789205-4a05ebb8d026?w=300&q=80' },
  { name: 'NUMBUZIN', bg: 'bg-purple-50', image: 'https://images.unsplash.com/photo-1648712789552-a039336cecf9?w=300&q=80' },
];

export function TrendingBrands() {
  return (
    <section className="py-10 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-4">
        <h2
          className="text-2xl font-bold mb-6 text-center"
          style={{ fontFamily: 'DM Serif Display, serif' }}
        >
          Trending Brands
        </h2>
        <div className="grid grid-cols-3 sm:grid-cols-5 gap-3">
          {trendingBrands.map((brand) => (
            <a
              key={brand.name}
              href="#"
              className={`${brand.bg} rounded-xl overflow-hidden aspect-square relative group hover:scale-[1.02] transition-transform`}
            >
              <img
                src={brand.image}
                alt={brand.name}
                className="w-full h-full object-cover opacity-60 group-hover:opacity-70 transition-opacity"
              />
              <div className="absolute inset-0 flex items-end p-3">
                <span className="text-xs font-bold tracking-widest text-foreground bg-white/80 backdrop-blur-sm px-2 py-1 rounded-full">
                  {brand.name}
                </span>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
