const cards = [
  {
    title: 'SKINCARE QUIZ',
    description: 'Take our quick quiz to get your own personalized product recommendations!',
    cta: 'TAKE THE QUIZ',
    bg: 'bg-rose-50',
    accent: 'hsl(336, 72%, 55%)',
    image: 'https://images.unsplash.com/photo-1686831757685-de3cadfc2325?w=400&q=80',
  },
  {
    title: 'ABOUT US',
    description: 'Learn who we are and what we stand for — read a special message from our founder!',
    cta: 'LEARN MORE',
    bg: 'bg-sky-50',
    accent: '#0EA5E9',
    image: 'https://images.unsplash.com/photo-1648712787765-82c244f76a1d?w=400&q=80',
  },
  {
    title: 'WHY GLOWIFY',
    description: 'Discover why Glowify skincare is trusted by thousands of happy customers worldwide!',
    cta: 'READ MORE',
    bg: 'bg-emerald-50',
    accent: '#059669',
    image: 'https://images.unsplash.com/photo-1648712789205-4a05ebb8d026?w=400&q=80',
  },
];

export function InfoCards() {
  return (
    <section className="py-10 bg-secondary/30">
      <div className="max-w-7xl mx-auto px-4">
        <h2
          className="text-xl font-bold mb-5 text-center"
          style={{ fontFamily: 'DM Serif Display, serif' }}
        >
          New to Glowify?
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {cards.map((card) => (
            <div
              key={card.title}
              className={`${card.bg} rounded-2xl overflow-hidden group hover:scale-[1.01] transition-transform`}
            >
              <div className="relative h-40 overflow-hidden">
                <img
                  src={card.image}
                  alt={card.title}
                  className="w-full h-full object-cover opacity-50 group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <h3
                    className="text-lg font-bold tracking-widest uppercase"
                    style={{ color: card.accent }}
                  >
                    {card.title}
                  </h3>
                </div>
              </div>
              <div className="p-5">
                <p className="text-sm text-muted-foreground mb-4">{card.description}</p>
                <a
                  href="#"
                  className="inline-flex items-center px-4 py-2 rounded-full text-xs font-bold text-white transition-all hover:scale-105"
                  style={{ backgroundColor: card.accent }}
                >
                  {card.cta} →
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
