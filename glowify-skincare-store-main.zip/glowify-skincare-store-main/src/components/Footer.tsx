import { Instagram, Facebook, Youtube, MessageCircle } from 'lucide-react';

const footerLinks: Record<string, string[]> = {
  Shop: ['Cleansers', 'Toners', 'Serums', 'Moisturizers', 'Eye Care', 'Sunscreens', 'Glowify Make-Up'],
  Account: ['My Account', 'Order History', 'Shopping Cart', 'Wishlist'],
  Info: ['About Us', 'Contact', 'Shipping & Delivery', 'Privacy Policy', 'Terms & Conditions', 'FAQ'],
  Countries: ['Netherlands', 'Belgium', 'Germany', 'France', 'United Kingdom', 'Portugal'],
};

export function Footer() {
  return (
    <footer className="bg-foreground text-white">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 mb-10">
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <h3
              className="text-2xl font-bold mb-2"
              style={{ fontFamily: 'DM Serif Display, serif', color: 'hsl(336, 72%, 75%)' }}
            >
              Glowify
            </h3>
            <p className="text-white/60 text-xs leading-relaxed mb-4">
              Your specialist in premium skincare. Free shipping from €40.
            </p>
            <div className="flex gap-3">
              {[Instagram, Facebook, Youtube, MessageCircle].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-8 h-8 bg-white/10 hover:bg-primary rounded-full flex items-center justify-center transition-colors"
                  aria-label="Social media"
                >
                  <Icon size={14} />
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          {Object.entries(footerLinks).map(([title, links]) => (
            <div key={title}>
              <h4 className="text-xs font-bold tracking-widest uppercase text-white/90 mb-3">
                {title}
              </h4>
              <ul className="space-y-2">
                {links.map((link) => (
                  <li key={link}>
                    <a href="#" className="text-xs text-white/50 hover:text-white transition-colors">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom */}
        <div className="pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-white/40 text-xs">
            © 2025 Glowify Skincare. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <span className="text-white/40 text-xs">
              iDEAL • Visa • Mastercard • PayPal • Klarna
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
