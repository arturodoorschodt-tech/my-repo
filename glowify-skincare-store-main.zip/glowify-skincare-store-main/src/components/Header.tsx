import { useState } from 'react';
import { Search, Heart, ShoppingBag, User, Menu, X, ChevronDown } from 'lucide-react';

const navItems = [
  {
    label: 'Skincare',
    children: [
      { label: 'Cleansers', href: '#' },
      { label: 'Toners', href: '#' },
      { label: 'Serums', href: '#' },
      { label: 'Moisturizers', href: '#' },
      { label: 'Face Masks', href: '#' },
      { label: 'Sunscreens', href: '#' },
      { label: 'Eye Care', href: '#' },
      { label: 'Exfoliants', href: '#' },
    ],
  },
  {
    label: 'Brands',
    children: [
      { label: 'Anua', href: '#' },
      { label: 'Beauty of Joseon', href: '#' },
      { label: 'COSRX', href: '#' },
      { label: 'SKIN1004', href: '#' },
      { label: 'Purito Seoul', href: '#' },
      { label: 'Numbuzin', href: '#' },
      { label: 'AESTURA', href: '#' },
      { label: 'Medicube', href: '#' },
    ],
  },
  { label: 'New In', href: '#' },
  { label: 'Bestsellers', href: '#' },
  { label: '✨Sale✨', href: '#', highlight: true },
  { label: 'Support', href: '#' },
];

export function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [cartCount] = useState(0);

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-border shadow-sm">
      {/* Top utility bar */}
      <div className="border-b border-border/50 hidden lg:block">
        <div className="max-w-7xl mx-auto px-4 flex justify-end items-center gap-4 py-1.5 text-xs text-muted-foreground">
          <a href="#" className="hover:text-foreground transition-colors">Sign In</a>
          <a href="#" className="hover:text-foreground transition-colors">Register</a>
          <a href="#" className="hover:text-foreground transition-colors">EN | NL | DE</a>
        </div>
      </div>

      {/* Main header */}
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Mobile menu button */}
          <button
            className="lg:hidden p-2 -ml-2"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Menu"
          >
            {mobileOpen ? <X size={22} /> : <Menu size={22} />}
          </button>

          {/* Logo */}
          <a href="#" className="flex items-center">
            <span
              className="text-2xl font-bold tracking-tight"
              style={{ fontFamily: 'DM Serif Display, serif', color: 'hsl(var(--primary))' }}
            >
              Glowify
            </span>
            <span className="text-xs text-muted-foreground ml-1 hidden sm:block" style={{ fontFamily: 'DM Sans, sans-serif' }}>
              skincare
            </span>
          </a>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => (
              <div
                key={item.label}
                className="relative group"
                onMouseEnter={() => item.children && setActiveDropdown(item.label)}
                onMouseLeave={() => setActiveDropdown(null)}
              >
                <a
                  href={item.href || '#'}
                  className={`flex items-center gap-1 px-3 py-2 text-sm font-medium rounded transition-colors hover:text-primary ${
                    item.highlight ? 'text-[hsl(18,85%,55%)]' : 'text-foreground'
                  }`}
                >
                  {item.label}
                  {item.children && <ChevronDown size={14} className="opacity-60" />}
                </a>

                {item.children && activeDropdown === item.label && (
                  <div className="absolute top-full left-0 w-52 bg-white border border-border rounded-lg shadow-lg py-2 animate-fade-in z-50">
                    {item.children.map((child) => (
                      <a
                        key={child.label}
                        href={child.href}
                        className="block px-4 py-2 text-sm text-foreground hover:bg-secondary hover:text-primary transition-colors"
                      >
                        {child.label}
                      </a>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <button className="p-2 hover:bg-secondary rounded-full transition-colors" aria-label="Search">
              <Search size={20} />
            </button>
            <button className="p-2 hover:bg-secondary rounded-full transition-colors hidden sm:flex" aria-label="Wishlist">
              <Heart size={20} />
            </button>
            <button className="p-2 hover:bg-secondary rounded-full transition-colors hidden sm:flex" aria-label="Account">
              <User size={20} />
            </button>
            <button className="p-2 hover:bg-secondary rounded-full transition-colors relative" aria-label="Cart">
              <ShoppingBag size={20} />
              {cartCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 bg-primary text-white text-xs w-4 h-4 rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="lg:hidden border-t border-border bg-white animate-fade-in">
          <nav className="max-w-7xl mx-auto px-4 py-4 flex flex-col gap-1">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href || '#'}
                className={`px-3 py-2.5 text-sm font-medium rounded-lg hover:bg-secondary transition-colors ${
                  item.highlight ? 'text-[hsl(18,85%,55%)]' : ''
                }`}
                onClick={() => setMobileOpen(false)}
              >
                {item.label}
              </a>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
}
