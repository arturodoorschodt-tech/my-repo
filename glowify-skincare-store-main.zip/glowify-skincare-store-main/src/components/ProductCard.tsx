import { ShoppingCart, Star, Share2 } from 'lucide-react';
import { toast } from 'react-hot-toast';
import type { Product } from '../data/products';

interface ProductCardProps {
  product: Product;
  onShare?: (product: Product) => void;
}

export function ProductCard({ product, onShare }: ProductCardProps) {
  const discount = product.originalPrice
    ? Math.round((1 - product.price / product.originalPrice) * 100)
    : null;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    toast.success(`${product.name} added to cart!`);
  };

  return (
    <div className="product-card group relative bg-white rounded-xl border border-border hover:border-primary/30 hover:shadow-md transition-all duration-200 overflow-hidden flex-shrink-0">
      {/* Image */}
      <div className="relative overflow-hidden bg-secondary aspect-square">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />
        {/* Badges */}
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {product.isNew && (
            <span className="bg-primary text-white text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wide">
              New
            </span>
          )}
          {discount && (
            <span className="bg-[hsl(var(--accent))] text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
              -{discount}%
            </span>
          )}
        </div>
        {/* Share button */}
        {onShare && (
          <button
            onClick={(e) => {
              e.preventDefault();
              onShare(product);
            }}
            className="absolute top-2 right-2 w-7 h-7 bg-white/80 hover:bg-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all shadow-sm"
            aria-label="Share product"
          >
            <Share2 size={12} className="text-foreground" />
          </button>
        )}
        {/* Add to cart on hover */}
        <div className="add-to-cart-btn absolute bottom-2 left-2 right-2">
          <button
            onClick={handleAddToCart}
            className="w-full bg-primary text-white text-xs font-semibold py-2 rounded-lg flex items-center justify-center gap-1.5 hover:bg-primary/90 transition-colors"
          >
            <ShoppingCart size={13} />
            Add to Cart
          </button>
        </div>
      </div>

      {/* Info */}
      <div className="p-3">
        <p className="text-[10px] font-bold tracking-wider uppercase text-primary mb-0.5">{product.brand}</p>
        <h3 className="text-xs font-medium text-foreground line-clamp-2 leading-snug mb-1.5">{product.name}</h3>

        {/* Rating */}
        <div className="flex items-center gap-1 mb-2">
          <div className="flex">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                size={9}
                className={
                  i < Math.floor(product.rating)
                    ? 'text-amber-400 fill-amber-400'
                    : 'text-gray-200 fill-gray-200'
                }
              />
            ))}
          </div>
          <span className="text-[10px] text-muted-foreground">({product.reviewCount.toLocaleString()})</span>
        </div>

        {/* Price */}
        <div className="flex items-center gap-1.5">
          <span className="text-sm font-bold text-foreground">€{product.price.toFixed(2)}</span>
          {product.originalPrice && (
            <span className="text-xs text-muted-foreground line-through">
              €{product.originalPrice.toFixed(2)}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
