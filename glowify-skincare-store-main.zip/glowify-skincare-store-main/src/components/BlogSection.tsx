const blogs = [
  {
    title: 'How to Choose the Best Moisturizer for Sensitive Skin',
    excerpt: 'Find the right Glowify moisturizer for sensitive skin in our comprehensive guide.',
    image: 'https://images.unsplash.com/photo-1686831757685-de3cadfc2325?w=500&q=80',
    date: 'March 15, 2025',
  },
  {
    title: 'The Ultimate Guide to Moisturizers for Dry Skin',
    excerpt: 'Learn how to choose the best Glowify moisturizer for dry skin with our expert tips.',
    image: 'https://images.unsplash.com/photo-1648712787765-82c244f76a1d?w=500&q=80',
    date: 'March 10, 2025',
  },
  {
    title: 'Best Glowify Moisturizers for Oily Skin',
    excerpt: 'Struggling with excess oil? Discover the best Glowify moisturizers for oily skin types.',
    image: 'https://images.unsplash.com/photo-1686831889344-f8cb3a384bc0?w=500&q=80',
    date: 'March 5, 2025',
  },
];

export function BlogSection() {
  return (
    <section className="py-10 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold" style={{ fontFamily: 'DM Serif Display, serif' }}>
            Latest GlowTalks
          </h2>
          <a href="#" className="text-sm font-medium text-primary hover:underline">
            View all posts →
          </a>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {blogs.map((blog) => (
            <a key={blog.title} href="#" className="group block">
              <div className="rounded-xl overflow-hidden mb-3 aspect-video">
                <img
                  src={blog.image}
                  alt={blog.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <p className="text-xs text-muted-foreground mb-1">{blog.date}</p>
              <h3 className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors line-clamp-2 mb-1">
                {blog.title}
              </h3>
              <p className="text-xs text-muted-foreground line-clamp-2">{blog.excerpt}</p>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
