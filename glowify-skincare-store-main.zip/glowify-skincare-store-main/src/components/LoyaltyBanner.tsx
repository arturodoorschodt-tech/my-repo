export function LoyaltyBanner() {
  return (
    <section className="py-12 bg-gradient-to-r from-primary to-[hsl(320,70%,50%)]">
      <div className="max-w-7xl mx-auto px-4 text-center text-white">
        <h2
          className="text-3xl font-bold mb-3"
          style={{ fontFamily: 'DM Serif Display, serif' }}
        >
          Member Benefits
        </h2>
        <p className="text-white/90 mb-6 max-w-lg mx-auto">
          Join the Glowify loyalty program! Earn ✨ Glowify Points ✨ and redeem them for exclusive
          discounts or free products.
        </p>
        <a
          href="#"
          className="inline-flex items-center px-8 py-3 bg-white text-primary font-semibold rounded-full text-sm hover:scale-105 transition-transform active:scale-95"
        >
          Join Now →
        </a>
      </div>
    </section>
  );
}
