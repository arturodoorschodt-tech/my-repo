import { useState } from 'react';
import { products, newProductCategories } from '../data/products';
import { ProductCard } from './ProductCard';
import type { Product } from '../data/products';

interface Props {
  onShare: (p: Product) => void;
}

export function NewProductsSection({ onShare }: Props) {
  const [activeTab, setActiveTab] = useState('New');

  const filtered =
    activeTab === 'New'
      ? products.filter((p) => p.isNew)
      : products.filter((p) => p.category === activeTab);

  const displayProducts = filtered.length > 0 ? filtered : products.slice(0, 8);

  return (
    <section className="py-10 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold" style={{ fontFamily: 'DM Serif Display, serif' }}>
            New Arrivals
          </h2>
          <a href="#" className="text-sm font-medium text-primary hover:underline">
            View all →
          </a>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2 scrollbar-hide">
          {newProductCategories.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-shrink-0 px-4 py-1.5 rounded-full text-xs font-semibold border transition-all ${
                activeTab === tab
                  ? 'bg-primary text-white border-primary'
                  : 'bg-white text-foreground border-border hover:border-primary hover:text-primary'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Products horizontal scroll */}
        <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
          {displayProducts.map((p) => (
            <div key={p.id} className="w-[180px] flex-shrink-0">
              <ProductCard product={p} onShare={onShare} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
