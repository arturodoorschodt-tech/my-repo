import { useState } from 'react';
import { X } from 'lucide-react';

const announcements = [
  '15% OFF IUNIK + FREE BETA GLUCAN SERUM ON GLOWIFY ORDERS OVER €20',
  'FREE SHIPPING FROM €40 • ORDER BEFORE 23:45 FOR NEXT-DAY DELIVERY',
  'NEW GLOWIFY ARRIVALS + FREE GLOW MILKY TONER ON ORDERS OVER €35',
];

export function AnnouncementBar() {
  const [dismissed, setDismissed] = useState(false);
  if (dismissed) return null;

  return (
    <div className="bg-[hsl(var(--primary))] text-white text-xs font-medium relative overflow-hidden">
      <div className="flex overflow-hidden">
        <div className="flex animate-marquee whitespace-nowrap py-2.5">
          {[...announcements, ...announcements].map((a, i) => (
            <span key={i} className="mx-8 tracking-wide uppercase">{a}</span>
          ))}
        </div>
      </div>
      <button
        onClick={() => setDismissed(true)}
        className="absolute right-3 top-1/2 -translate-y-1/2 hover:opacity-70 transition-opacity"
        aria-label="Dismiss"
      >
        <X size={14} />
      </button>
    </div>
  );
}
