import { products } from '../data/products';
import { ProductCard } from './ProductCard';
import type { Product } from '../data/products';

interface Props {
  onShare: (p: Product) => void;
}

export function BestsellersSection({ onShare }: Props) {
  const bestsellers = products
    .filter((p) => !p.isNew)
    .sort((a, b) => b.reviewCount - a.reviewCount);

  return (
    <section className="py-10 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold" style={{ fontFamily: 'DM Serif Display, serif' }}>
            Bestsellers
          </h2>
          <a href="#" className="text-sm font-medium text-primary hover:underline">
            View all →
          </a>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
          {bestsellers.map((p) => (
            <ProductCard key={p.id} product={p} onShare={onShare} />
          ))}
        </div>
      </div>
    </section>
  );
}
