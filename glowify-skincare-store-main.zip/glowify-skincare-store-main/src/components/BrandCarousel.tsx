const brands = [
  'ANUA', 'GOODAL', 'BEAUTY OF JOSEON', 'AXIS-Y', 'SKIN1004',
  'DR. CEURACLE', 'MARY MAY', 'IUNIK', 'PURITO SEOUL', 'TORRIDEN',
  'COSRX', 'NUMBUZIN',
];

export function BrandCarousel() {
  return (
    <div className="border-y border-border bg-white py-4 overflow-hidden">
      <div className="flex">
        <div className="flex animate-marquee whitespace-nowrap">
          {[...brands, ...brands].map((brand, i) => (
            <span
              key={i}
              className="mx-8 text-xs font-bold tracking-widest uppercase text-muted-foreground hover:text-primary cursor-pointer transition-colors flex-shrink-0"
            >
              {brand}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
