import { Truck, Gift, Clock } from 'lucide-react';

const trustItems = [
  { icon: Clock, text: 'Order before 23:45 for next-day delivery', href: '#' },
  { icon: Gift, text: 'Free face mask on orders over €40', href: '#' },
  { icon: Truck, text: 'Free shipping from €40 (EU)', href: '#' },
];

export function TrustBar() {
  return (
    <div className="bg-secondary border-b border-border">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex flex-col sm:flex-row items-center justify-center sm:divide-x divide-border">
          {trustItems.map(({ icon: Icon, text, href }) => (
            <a
              key={text}
              href={href}
              className="flex items-center gap-2 px-4 sm:px-8 py-2.5 text-xs font-medium text-foreground hover:text-primary transition-colors"
            >
              <Icon size={14} className="text-primary flex-shrink-0" />
              <span>{text}</span>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
