import { useState } from 'react';
import { Share2, Copy, Check, MessageCircle, Send, Link } from 'lucide-react';
import { toast } from 'react-hot-toast';
import type { Product } from '../data/products';

interface Props {
  product?: Product | null;
  onClose?: () => void;
}

export function ShareProductBanner({ product, onClose }: Props) {
  const [copied, setCopied] = useState(false);
  const shareUrl = product
    ? `${window.location.origin}?product=${product.id}`
    : `${window.location.origin}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(shareUrl).then(() => {
      setCopied(true);
      toast.success('Link copied!');
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const shareText = product
    ? `Check out this product at Glowify: ${product.name} – €${product.price.toFixed(2)}`
    : 'Check out the Glowify skincare collection!';

  const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(shareText + ' ' + shareUrl)}`;
  const telegramUrl = `https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareText)}`;

  if (product) {
    // Modal sharing overlay
    return (
      <div
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-fade-in"
        onClick={onClose}
      >
        <div
          className="bg-white rounded-2xl shadow-xl max-w-sm w-full p-6 animate-slide-in"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
              <Share2 size={18} className="text-primary" />
            </div>
            <div>
              <h3 className="font-bold text-sm">Share Product</h3>
              <p className="text-xs text-muted-foreground">Share with friends</p>
            </div>
            <button
              onClick={onClose}
              className="ml-auto text-muted-foreground hover:text-foreground text-xl leading-none"
            >
              &times;
            </button>
          </div>

          {/* Product preview */}
          <div className="flex gap-3 p-3 bg-secondary rounded-xl mb-4">
            <img
              src={product.image}
              alt={product.name}
              className="w-14 h-14 rounded-lg object-cover"
            />
            <div className="flex-1 min-w-0">
              <p className="text-[10px] font-bold uppercase text-primary">{product.brand}</p>
              <p className="text-xs font-medium line-clamp-2">{product.name}</p>
              <p className="text-sm font-bold mt-0.5">€{product.price.toFixed(2)}</p>
            </div>
          </div>

          {/* Share options */}
          <div className="grid grid-cols-2 gap-2 mb-4">
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 px-4 py-2.5 bg-[#25D366] text-white text-sm font-semibold rounded-xl hover:opacity-90 transition-opacity"
            >
              <MessageCircle size={16} />
              WhatsApp
            </a>
            <a
              href={telegramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 px-4 py-2.5 bg-[#2CA5E0] text-white text-sm font-semibold rounded-xl hover:opacity-90 transition-opacity"
            >
              <Send size={16} />
              Telegram
            </a>
          </div>

          {/* Copy link */}
          <div className="flex items-center gap-2 p-3 bg-muted rounded-xl">
            <Link size={14} className="text-muted-foreground flex-shrink-0" />
            <span className="text-xs text-muted-foreground truncate flex-1">{shareUrl}</span>
            <button
              onClick={handleCopy}
              className="flex items-center gap-1 px-3 py-1.5 bg-primary text-white text-xs font-semibold rounded-lg hover:bg-primary/90 transition-colors flex-shrink-0"
            >
              {copied ? <Check size={12} /> : <Copy size={12} />}
              {copied ? 'Copied' : 'Copy'}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Static section banner
  return (
    <section className="py-10 bg-gradient-to-r from-secondary via-white to-secondary border-y border-border">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center gap-6 text-center md:text-left">
          <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center flex-shrink-0">
            <Share2 size={32} className="text-primary" />
          </div>
          <div className="flex-1">
            <h2
              className="text-2xl font-bold mb-1"
              style={{ fontFamily: 'DM Serif Display, serif' }}
            >
              Share Products with Friends
            </h2>
            <p className="text-sm text-muted-foreground">
              Found something you love? Easily share any product via WhatsApp, Telegram or a direct
              link with your friends and family.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-2 flex-shrink-0">
            <button
              onClick={handleCopy}
              className="flex items-center justify-center gap-2 px-5 py-2.5 border border-primary text-primary text-sm font-semibold rounded-full hover:bg-primary hover:text-white transition-all"
            >
              {copied ? <Check size={15} /> : <Copy size={15} />}
              {copied ? 'Copied!' : 'Copy link'}
            </button>
            <a
              href={`https://wa.me/?text=${encodeURIComponent('Check out Glowify skincare: ' + window.location.origin)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 px-5 py-2.5 bg-[#25D366] text-white text-sm font-semibold rounded-full hover:opacity-90 transition-opacity"
            >
              <MessageCircle size={15} />
              Share on WhatsApp
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
