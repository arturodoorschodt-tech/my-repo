export interface Product {
  id: string;
  name: string;
  brand: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviewCount: number;
  image: string;
  badge?: string;
  category: string;
  isNew?: boolean;
}

export const products: Product[] = [
  { id: '1', name: 'Heartleaf Pore Control Cleansing Oil', brand: 'Anua', price: 15.64, originalPrice: 19.95, rating: 4.8, reviewCount: 2085, image: 'https://images.unsplash.com/photo-1686831757685-de3cadfc2325?w=400&q=80', badge: '-22%', category: 'Cleansers', isNew: false },
  { id: '2', name: 'Bio-Collagen Real Deep Mask', brand: 'Biodance', price: 4.70, originalPrice: 6.95, rating: 4.7, reviewCount: 470, image: 'https://images.unsplash.com/photo-1686831889344-f8cb3a384bc0?w=400&q=80', badge: '-32%', category: 'Face Masks', isNew: false },
  { id: '3', name: 'Relief Sun : Rice + Probiotics SPF50+', brand: 'Beauty of Joseon', price: 14.25, originalPrice: 17.90, rating: 4.9, reviewCount: 6301, image: 'https://images.unsplash.com/photo-1686831889593-d49e5cf9300d?w=400&q=80', badge: '-20%', category: 'Sunscreens', isNew: false },
  { id: '4', name: 'Dark Spot Correcting Glow Serum', brand: 'AXIS-Y', price: 14.45, originalPrice: 17.95, rating: 4.8, reviewCount: 1671, image: 'https://images.unsplash.com/photo-1648712787765-82c244f76a1d?w=400&q=80', badge: '-19%', category: 'Serums', isNew: false },
  { id: '5', name: 'Glow Serum Propolis+Niacinamide', brand: 'Beauty of Joseon', price: 13.42, originalPrice: 13.95, rating: 4.8, reviewCount: 2416, image: 'https://images.unsplash.com/photo-1648712789205-4a05ebb8d026?w=400&q=80', category: 'Serums', isNew: false },
  { id: '6', name: 'Madagascar Centella Ampoule', brand: 'SKIN1004', price: 10.95, rating: 4.7, reviewCount: 1387, image: 'https://images.unsplash.com/photo-1648712789552-a039336cecf9?w=400&q=80', category: 'Serums', isNew: false },
  { id: '7', name: 'Airy Fit Sheet Mask', brand: 'MISSHA', price: 1.89, rating: 4.6, reviewCount: 1025, image: 'https://images.unsplash.com/photo-1611861317409-7dcc62856a8a?w=400&q=80', category: 'Face Masks', isNew: false },
  { id: '8', name: 'Acne Pimple Master Patches', brand: 'COSRX', price: 3.92, originalPrice: 4.36, rating: 4.9, reviewCount: 2339, image: 'https://images.unsplash.com/photo-1648712787208-7d52a79c4273?w=400&q=80', badge: '-10%', category: 'Treatments', isNew: false },
  { id: '9', name: 'No.3 Blue Bio-Retinol Pore Refining Serum', brand: 'Numbuzin', price: 20.95, rating: 4.7, reviewCount: 45, image: 'https://images.unsplash.com/photo-1686831757685-de3cadfc2325?w=400&q=80', category: 'Serums', isNew: true },
  { id: '10', name: 'Collagen Mask To Foam Cleanser', brand: 'Biodance', price: 19.95, rating: 4.6, reviewCount: 12, image: 'https://images.unsplash.com/photo-1686831889344-f8cb3a384bc0?w=400&q=80', category: 'Cleansers', isNew: true },
  { id: '11', name: 'PDRN Exosome Skinplaning Glaze Mask', brand: 'COSRX', price: 21.95, rating: 4.5, reviewCount: 8, image: 'https://images.unsplash.com/photo-1686831889593-d49e5cf9300d?w=400&q=80', category: 'Face Masks', isNew: true },
  { id: '12', name: 'Atobarrier 365 Cream', brand: 'AESTURA', price: 30.95, rating: 4.8, reviewCount: 22, image: 'https://images.unsplash.com/photo-1648712787765-82c244f76a1d?w=400&q=80', category: 'Moisturizers', isNew: true },
  { id: '13', name: 'PDRN Pink Cica Soothing Toner', brand: 'Medicube', price: 18.45, rating: 4.6, reviewCount: 5, image: 'https://images.unsplash.com/photo-1648712789205-4a05ebb8d026?w=400&q=80', category: 'Toners', isNew: true },
  { id: '14', name: 'Azelaic Acid 10 Kojic Tea Tree Serum', brand: 'Purito Seoul', price: 21.95, rating: 4.7, reviewCount: 18, image: 'https://images.unsplash.com/photo-1648712789552-a039336cecf9?w=400&q=80', category: 'Serums', isNew: true },
  { id: '15', name: 'Dynasty Cream', brand: 'Beauty of Joseon', price: 18.97, originalPrice: 23.95, rating: 4.8, reviewCount: 2322, image: 'https://images.unsplash.com/photo-1611861317409-7dcc62856a8a?w=400&q=80', badge: '-21%', category: 'Moisturizers', isNew: false },
  { id: '16', name: 'Oat-In Calming Gel Cream', brand: 'Purito Seoul', price: 14.95, rating: 4.7, reviewCount: 310, image: 'https://images.unsplash.com/photo-1648712787208-7d52a79c4273?w=400&q=80', category: 'Moisturizers', isNew: false },
];

export const newProductCategories = ['New', 'Cleansers', 'Moisturizers', 'Face Masks', 'Sunscreens', 'Serums'];
