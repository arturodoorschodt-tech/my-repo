import { useState } from 'react';
import { Toaster } from 'react-hot-toast';
import { AnnouncementBar } from './components/AnnouncementBar';
import { Header } from './components/Header';
import { TrustBar } from './components/TrustBar';
import { HeroSlider } from './components/HeroSlider';
import { BrandCarousel } from './components/BrandCarousel';
import { NewProductsSection } from './components/NewProductsSection';
import { FreeGiftsSection } from './components/FreeGiftsSection';
import { BestsellersSection } from './components/BestsellersSection';
import { TrendingBrands } from './components/TrendingBrands';
import { InfoCards } from './components/InfoCards';
import { CategoriesSection } from './components/CategoriesSection';
import { LoyaltyBanner } from './components/LoyaltyBanner';
import { ShareProductBanner } from './components/ShareProductBanner';
import { BlogSection } from './components/BlogSection';
import { Footer } from './components/Footer';
import type { Product } from './data/products';

export default function App() {
  const [shareProduct, setShareProduct] = useState<Product | null>(null);

  return (
    <div className="min-h-screen bg-background">
      <Toaster position="top-right" />
      <AnnouncementBar />
      <Header />
      <TrustBar />
      <HeroSlider />
      <BrandCarousel />
      <NewProductsSection onShare={setShareProduct} />
      <FreeGiftsSection />
      <BestsellersSection onShare={setShareProduct} />
      <TrendingBrands />
      <InfoCards />
      <CategoriesSection />
      {/* Glowify exclusive share feature */}
      <ShareProductBanner />
      <LoyaltyBanner />
      <BlogSection />
      <Footer />

      {/* Share modal */}
      {shareProduct && (
        <ShareProductBanner product={shareProduct} onClose={() => setShareProduct(null)} />
      )}
    </div>
  );
}
